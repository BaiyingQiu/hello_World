//: Playground - noun: a place where people can play

import UIKit

//集合最大的特点就是没有重复的数据

var letters : Set<Character> = Set<Character>()
letters.insert("A")
letters.insert("B")
letters.insert("C")
letters.insert("A")
letters.count

var musics : Set<String> = ["Rock", "Classical", "Jazz"]
musics.count
musics.isEmpty//判断是否为空

//增加数据
musics.insert("Jazz")
musics.insert("Hip hop")

//删除数据
if let removeMusic = musics.remove("Hip hop") {
    print("删除音乐风格 \(removeMusic)")
} else {
    print("没有该音乐风格")
}

//判断是否含某个元素
musics.contains("Jazz")

//遍历
for music in musics {
    print(music)
}

//排序
musics
musics.sort()

//集合运算
var oddDigits : Set = [1, 3, 5, 7, 9]
let evenDigits : Set = [1, 3, 5, 8, 10]
//并集
var newNums = oddDigits.union(evenDigits)
//交集
newNums = oddDigits.intersect(evenDigits)
//差
newNums = oddDigits.subtract(evenDigits)
//补集
newNums = oddDigits.exclusiveOr(evenDigits)


