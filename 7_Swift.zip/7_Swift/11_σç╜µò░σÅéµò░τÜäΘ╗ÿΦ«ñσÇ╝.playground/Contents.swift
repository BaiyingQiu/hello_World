//: Playground - noun: a place where people can play

import UIKit

/**
    一个函数的参数 可以设定默认值 如果这个参数不传入值 则使用默认值
*/
func printArray(array : [Int] = [6,7,8,9,10], spli : String = ",", flag :Bool = true) {
    if flag {
        print("[")
    }
    for var i = 0; i < array.count - 1; i++ {
            print("\(array[i])\(spli)")
    }
    print(array[array.count - 1])
    if flag {
        print("]")
    }
}
var array = [1,2,3,4,5]
printArray(array, spli: ",", flag: true)
printArray(array, flag: true)
printArray(array)
printArray()