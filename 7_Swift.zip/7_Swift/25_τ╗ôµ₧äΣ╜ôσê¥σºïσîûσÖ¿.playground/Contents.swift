//: Playground - noun: a place where people can play

import UIKit

struct MyStruct {
    var d : double_t = 0.0
    var x : Int = 0
    // 所有属性初始化之后会提供一个无参的 和 一个逐一的初始化器
    // 如果我们自己提供了初始化器 则表一起不再帮我们生成初始化器
    init(d : Double){
        self.d = d
        self.x = 0
    }
    init() {
        self.x = 1
    }
}
var ms = MyStruct()
ms.d
ms.x

struct Color {
    let red, green, blue : Double
    //初始化器
    init(red : Double, green : Double, blue : Double) {
        self.red = red
        self.blue = blue
        self.green = green
    }
    init(_ red : Double, _ green : Double, _ blue : Double) {
        self.init(red : red, green : green, blue : blue)
    }
}
//var color = Color(red: 1, green: 2, blue: 3)
var color = Color(11, 22, 33)
color.red
