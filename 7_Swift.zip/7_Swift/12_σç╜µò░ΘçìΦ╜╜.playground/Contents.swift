//: Playground - noun: a place where people can play

import UIKit

/** 相同的函数名，参数列表不同（顺序，类型，个数） */
func add(x : Int, y : Int) -> Int {
    return x + y
}
func add(x : Int, y : Double) -> Double {
    return Double(x) + y
}
func add(x : Double, y : Int) -> Double {
    return x + Double(y)
}
func add(x : Int, y : Int, z : Int) -> Int {
    return x + y + z
}
add(2, y: 3)
add(2, y: 3.2)
add(1, y: 2, z: 3)