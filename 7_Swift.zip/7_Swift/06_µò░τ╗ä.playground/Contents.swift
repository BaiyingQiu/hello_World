//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var arr : Array<Int> = [1, 2, 3, 4, 5, 6, 7, 8]
print(arr)

var arr2 : Array<String> = ["123", "456", "789"]

//定义数组的几种形式
var array1 = Array<Int>()
var array2 : Array<Int> = Array<Int>()
var array3 : Array<Int> = Array()
var array4 : Array = Array<Int>()
var arrau5 : Array = [Int]()
var arrau6 : [Int] = Array()
var array7 : [Int] = [Int]()
var array8 = [1, 2, 3, 4, 5, 6, 7, 8]
// = 代表赋值  没有赋值无法输出

var myArr = ["11", "22", "33"]
//查
myArr[0]
//改
myArr[0] = "110"
myArr

//增加数据（尾部）
myArr.append("面粉")
myArr += ["大米"]
myArr += ["面包", "矿泉水", "泡面", "鸡蛋"]
//（指定位置）
myArr.insert("iphoneSE", atIndex: 1)

// 删除数据
myArr.removeAtIndex(0)
myArr.removeFirst()
myArr.removeLast()
myArr
var range = Range(start: 0, end: 2)
myArr.removeRange(range)

var subList = myArr[1 ... 2]

//遍历
for item in myArr {
    print(item)
}
print("------")
for item in subList {
    print(item)
}
print("------")
for var i = 0; i < myArr.count; i++ {
    print(myArr[i])
}