//: Playground - noun: a place where people can play

import UIKit

class MyClass {
    //类中的属性必须进行初始化 要么直接初始化 要么在初始化器中初始化 两个地方有一个地方初始化就不会报错
    var text : String = "123"
    init() {
        self.text = "abc"
    }
//    init() {
//        self.text = ""
//    }
    
}
//类类型 不提供逐一初始化器 只默认提供一个无参初始化器 但一旦我们提供了初始化器 系统回收之前的
MyClass().text

class Food {
    var name : String
    var count = 0
    // 提供一个初始化方法 完成对name 的初始化
    // 真正完成初始化的 叫指定初始化器
    init(name : String) {
        self.name = name
    }
    // 便利初始化器 最终会指定初始化器
    convenience init() {
        self.init(name : "abc")
    }
    convenience init (x : Double){
        self.init()
    }
}

class Apple : Food {
    var quantity : Int = 0
    // 指定初始化器
    init (name : String, quantity : Int) {
        //先初始化子类属性
        self.quantity = 1
        // 在调用父类的初始化器
        super.init(name : name)
        // 如果
        self.name = "xx"
    }
    //重写父类的初始化方法
//    convenience override init(name : String) {
//        self.name = name
//    }
    /** 对象销毁之前调用 */
    deinit {
        print("本对象将要销毁\(self)")
    }
}

