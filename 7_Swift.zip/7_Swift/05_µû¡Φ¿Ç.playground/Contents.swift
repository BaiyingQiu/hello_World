//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var x = 1001
assert(x != 100, "x不能等于100")
print("app continue")

func textAssert(partx : Int) -> Void {
    assert(partx != 0, "x不能为0")
    var i = 1.0 / partx;
}
textAssert(0)