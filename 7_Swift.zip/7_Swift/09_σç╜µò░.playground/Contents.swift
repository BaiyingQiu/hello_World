//: Playground - noun: a place where people can play

import UIKit

/**
    函数:完成特定功能的一组代码 并且有一个名字作为标记
    定义的格式：
    func 函数名(参数名：参数类型， 参数名：参数类型...) -> 返回值类型 {
        函数体
    }
*/

func myFunc(a : Int, b : Int) -> Int{
    return a+b
}
func sayHello() -> Void {
    print("Hello")
}
//没有返回值可以省略
func sayHello2() {
    print("Hello2")
}

var c = myFunc(2, b: 4)
print(c)

sayHello
sayHello()
sayHello2()

func sayHello3(personName : String) -> String{
    let msg = "Hello " + personName + "!"
    return msg

}
print(sayHello3("Heard"));

func printEmp(age : Int, name : String) {
    print("age:\(age)","name:\(name)");
}
printEmp(20, name: "BaiYing")



//统计字符在个数
let msgStr = "我我我, 你你你, 你好, 我不好"
func count(str : String) -> (me : Int, you : Int, other : Int){
    var m = 0, y = 0, o = 0;
    for ch in str.characters {
        switch ch {
            case "我":
            m++
            case "你":
            y++
            default:
            o++
        }
    }
    return (m, y, o);
}
let var_res = count(msgStr)
var_res.me
var_res.you
var_res.other

//使用C 设计一个函数， 完成两个函数的交换
//int swapTwoNum (char *x, char *y) {
//    int temp = *x;
//    *x = *y;
//    *y = temp;
//}

//使用Swift 设计一个函数， 完成两个函数的交换
func swapNum (inout var_x : Int, inout var_y : Int) -> Void {
    let temp = var_x
    var_x = var_y
    var_y = temp
}
var x = 20
var y = 300
swapNum(&x, var_y: &y)
x
y