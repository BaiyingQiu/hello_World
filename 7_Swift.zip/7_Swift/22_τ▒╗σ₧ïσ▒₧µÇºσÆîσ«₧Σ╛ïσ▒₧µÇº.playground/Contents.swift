//: Playground - noun: a place where people can play

import UIKit

/**
    类型属性
        在 结构体 中 或者枚举中 使用 static 修饰的属性
        以及在 类 中使用 static 或 class 修饰的属性
        在struct 中定义类型属性 可以修饰存储属性 也可以是计算属性
        在class 中定义类型属性 如果使用class修饰，不能修饰存储属性
 
    所谓类型属性 就是在类型中定义的全局数据
    只有一份

*/
struct struct1 {
    //存储属性
    var a = 10
    //计算属性
    var b : Int {
        return 120
    }
    //类型属性
    static var c = 20
    static var d : Int {
        return 110
    }
}

var s1 = struct1()
s1.a
//swift 不允许通过对象 直接访问类型属性
//需要类名才能访问
struct1.c
struct1.d

//

class Class1 {
    //存储属性
    var a = 10
    //计算属性
    var b : Int {
        return 120
    }
    //类型属性 static
    static var c = 20
    static var d : Int {
        return 110
    }
    //类型属性 class
    //不能修饰存储属性
    //class var dd = 20
    class var e: Int {
        return 111
    }
    
}

var c1 = Class1()
c1.a
Class1.c

