//: Playground - noun: a place where people can play

import UIKit

//函数类型
// void ()
// void test(); C函数声明
// void (*pfun)()
// void (*ptest)()
// pfun = test
// pfun = &test

//int x;
//int *px = &x;

//int getMax(int x, int y);
//int (pfun)(int x, int y);
//pfun = getMax

//没有参数 没有返回值的函数
// 函数类型  () -> Void
func sayHello() -> Void {
    print("hello")
}
//定义函数类型变量
var varFun = sayHello
varFun()

var varFun2 : () -> Void
varFun2 = sayHello
varFun2()

// 写出下面函数类型， 并定义一个变量，赋值然后调用
//(a : Int, b : Int) -> Int
//(Int, Int) -> Int
func addTwoInts(a : Int, b : Int) -> Int {
    return a + b
}
var pfun : (Int, Int) -> Int
pfun = addTwoInts
pfun(100, 200)
addTwoInts(100, b: 200)
var pfun3 : (a : Int, b : Int) -> Int
pfun3 = addTwoInts
pfun3(a : 100, b: 200)
var pfun4 = addTwoInts
pfun4(100, b: 2)

//函数类型参数



