//: Playground - noun: a place where people can play

import UIKit

/** 写一个函数 
    第一个参数 一个Int型参数
    第二个参数 是一个函数类型（）-> Int
    第三个参数 string 类型
    第四个参数 函数类型 Void -> Void
    如果第一个参数大于10 就调用第二个参数对应的函数 否则调用第四个参数对应的函数

*/

func funcTest(x : Int, function1 : () ->Int, str : String, function2 : Void -> Void){
    if x > 10 {
        function1()
    } else {
        function2()
    }
}
funcTest(11, function1: { () -> Int in
    print("function1")
    return 10
    }, str: "Hello", function2: { Void -> Void in
        print("Hi")
})
funcTest(10, function1: { () -> Int in
    return 20
    }, str: "hi") { ( ) -> Void in
        print("function2")
}
