//: Playground - noun: a place where people can play

import UIKit


/** 元组 Tuple 是将多个类型（可能相同），组织到一起的数据类型，类似C中的结构体变量 */
//
("张翔",21,210)
//定义
let http404Error : (Int, String) = (404, "Not found")
//如何访问元组数据对应的数据
http404Error.0
http404Error.1

let http500Error = (code:500, description:"Server error")
http500Error.0
http500Error.1
http500Error.code
http500Error.description

//
let http501Error : (code : Int, description : String) = (code : 501, description : "Server Error")
http501Error.code
http501Error.description
http501Error.0
http501Error.1

// 定义一个员工 对应的元组类型 需要保存员工的名字 年龄 和月薪
//创建元组变量
var var_emp : (name : String, age : Int, salary : Double)
var_emp = ("zhangsan", 22, 11000)
var_emp.name
var_emp.age
var_emp.salary





