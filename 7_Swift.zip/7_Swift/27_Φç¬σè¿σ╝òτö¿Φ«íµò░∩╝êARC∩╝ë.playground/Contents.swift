//: Playground - noun: a place where people can play

import UIKit

//循环强引用
class A {
    weak var b : B?
    init() {}
    deinit { print("A 将要被销毁")}
    
}

class B {
    var a : A?
    init() {}
    deinit{ print("B 将要被销毁")}
}

var a : A? = A()
var b : B? = B()
a?.b = b
b?.a = a

a = nil
b = nil
