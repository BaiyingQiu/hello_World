//: Playground - noun: a place where people can play

import UIKit

//属性监视器 
/*  提供两种状态
    willSet
    didSet

    默认提供两个值
    newValue
    oldValue

*/
class Test {
    var i : Int = 1 {
        willSet(newValue) {
            print("数据将要变成\(newValue), 现在的值是\(i)")
        }
        didSet {
            print("数据已经改变为\(i), 原来的值是\(oldValue)")
        }
    }
}

var test = Test()
test.i = 10
