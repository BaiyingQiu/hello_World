//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
let point = (0, 112)
/**
    判断这个点是否在原点 如果在就打印原点
    判断这个点是否在x轴 如果在就打印 x轴
    判断这个点是否在y轴 如果在就打印 y轴
    判断这个点是否在矩形 -20，20  -20，20 的矩形中  如果在就打印在规定的矩形内
*/
switch point {
case (0, 0):
    print("原点")
    //绑定值到x这个常量
case (let x, 0)://下划线忽略变量的值
    print("x轴")
case (0, _):
    print("y轴")
case (-20 ... 20, -20 ... 20):
    print("规定的矩形范围内")
default:
    print("其他位置");
}

/**
    写一个程序 定义一个元组代表一个点
    判断这个点 是否在原点 如果在就打印原点
    判断这个点 是否在x == y 的斜线上，如果在就打印“在x=y的斜线上”
    判断这个点 是否在x == -y 的斜线上，如果在就打印“在x=-y的斜线上”
*/

switch point {
case (0, 0):
    print("原点")
case let (x, y) where x == y:
    print("斜线1上")
case let (x, y) where x == -y:
    print("斜线-1上")
default:
    print("其他")
}
