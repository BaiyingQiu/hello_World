//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
// 创建字典
//标准
var dictionary1 : Dictionary<String, Int> = Dictionary<String, Int>()
var dictionary2 : Dictionary<String, Int> = Dictionary()
var dictionary3 : Dictionary = Dictionary<String, Int>()
var dictionary4 : Dictionary = [String: Int]()
var dictionary6 :[String : Int] = [String : Int]()
var dictionary5 = ["key" : "Value", "key2" : 2]
dictionary5["key"]
dictionary5["key2"]
var dictionary7 : [String : Int!] = ["age" : nil];
//没有分配内存空间
var dictionary8 : [String : Int]
//dictionary8.count
dictionary5.count

var airports = ["SZA" : "深圳机场", "SHA" : "上海机场", "TRA" : "达内机场"]
//查
airports["SZA"]
//改
airports["SZA"] = "深圳🐔场"
//改(可选绑定)
if let oldValue = airports.updateValue("深圳新机场", forKey: "SZA") {
    print("修改成功\(oldValue)")
}
//删(可选绑定)
if let airport = airports.removeValueForKey("SHA") {
    print("删除成功\(airport)")
} else {
    print("删除失败")
}

//遍历
//key
for airportKey in airports.keys {
    print("字典中的 Key \(airportKey)")
}
//value
for airportValue in airports.values {
    print("字典中的 Value \(airportValue)")
}

//通过Key 或 Value 创建数组
let airportKeys = [String](airports.keys)
airportKeys[0]

// Swift 中的字典是值类型
var dic : Dictionary = [1 : "one", 2 : "two"]
var dic2 = dic
dic[1] = "一"
dic2[1]

//使用NSMutableDictionary 完成上面的程序
//说明 OC 中 NSMutableDictionary 是引用类型
var nsDic : NSMutableDictionary = [1 : "one", 2 : "two"]
var nsdic2 = nsDic
nsDic[1] = "一"
nsdic2[1]

