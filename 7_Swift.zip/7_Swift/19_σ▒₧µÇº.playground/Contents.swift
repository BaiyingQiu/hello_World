//: Playground - noun: a place where people can play

import UIKit

/*  swift 中的属性
    第一种方式：
        存储属性：
            用变量或常量来存储属性的值
        计算属性：
            用计算结果来存储
        
    第二种方式：
        实例属性


*/
struct MyRange {
    //存储属性
    var location : Int
    //存储属性
    let length : Int
}
var myRange = MyRange(location: 100, length: 200)
myRange.location = 150

//计算属性
struct Point {
    var x = 0.0, y = 0.0
}
struct Size {
    var w = 0.0, h = 0.0
}
struct Rect {
    //存储属性
    var origin = Point()
    var size = Size()
    //中心点 计算属性
    var center : Point {
        // 获取中心点
        get {
            let centerX = origin.x + (size.w * 0.5)
            let centerY = origin.y + (size.h * 0.5)
            return Point(x: centerX, y: centerY)
        }
        // 设置中心点
        set (newCentter) {
            let newOrignX = newCentter.x - size.w * 0.5
            let newOrignY = newCentter.y - size.h * 0.5
            origin = Point(x: newOrignX, y: newOrignY)
        }
    }
}
var rec = Rect(origin: Point(), size: Size(w: 100, h: 100))
rec.center.x
rec.center.y

rec.center = Point(x: 100, y: 200)
rec.origin.x
rec.origin.y


