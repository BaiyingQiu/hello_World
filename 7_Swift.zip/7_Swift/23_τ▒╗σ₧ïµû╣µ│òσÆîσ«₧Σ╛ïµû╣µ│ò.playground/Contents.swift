//: Playground - noun: a place where people can play

import UIKit

//方法分为实例方法和类方法

class Counter {
    var count = 0
    static var count2 = 1
    //实例方法
    func increment() {
        count++
        Counter.count2 = 99
        Counter.count2
    }
    func increment(amout :Int) {
        count += amout
    }
}
//实例方法用对象调用
var counter = Counter()
counter.increment()
counter.increment(20)
counter.count

//值类型的实例方法
struct Point {
    var x = 10, y = 0
    var z = 200
    static var sx = 100
    func instatnceMethod() {
        print(x)
        print(y)
        print(z)
        //类型属性的初始化，远早于实例对象
        Point.sx = 110
        print(Point.sx)
        // 值类型中 默认不能修改实例属性 如果非要改 则使用mutating
//        x = 20
    }
    mutating func instanceMethond2() {
        print(x)
        x = 110
        print(x)
    }
    
}

Point().instatnceMethod()
var point = Point()
point.instanceMethond2()


//类型方法
class SomeClass {
    var prop : Int = 0
    static var a : Int {
        return 10
    }
    static func classMethod() {
        print("类型方法")
        print(SomeClass.a)
        print(self.a)
        //类方法不能访问实例变量
//        print(self.prop)
    }
}
SomeClass.classMethod()

// 结构体中如何定义类型方法
struct SomeStruct {
    var prop : Int = 0
    //定义一个类型属性 不能使用class修饰
    static var a : Int {
        return 10
    }
    static func classMethod() {
        print("类型方法")
        self.a
    }
}
SomeStruct.classMethod()



