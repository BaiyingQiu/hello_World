//: Playground - noun: a place where people can play

import UIKit

// 冒泡排序
// 比较相邻元素，满足条件就交换
// 通过参数，把比较规则传入
func popSort(inout data : [Int], function : (Int, Int) -> Bool) {
    for var i = 0; i < data.count - 1; i++ {
        for var j = 0; j < data.count - 1 - i; j++ {
            if (function(data[j], data[j+1])) {//将函数参数作为规则传进去
                let temp = data[j]
                data[j] = data[j+1]
                data[j+1] = temp
            }
        }
    }
}

var data = [10,2,8,1,3,7]
func greatorFun(x : Int, y : Int) -> Bool{
    return x > y
}
//传函数
popSort(&data, function: greatorFun)
//传闭包
popSort(&data) { (x : Int, y : Int) -> Bool in
    return x < y
}
data

// 闭包的可以缩写
// 参数类型 可以省略
popSort(&data) { (x, y) -> Bool in
    return x > y
}
// 返回值类型 可以省略
popSort(&data) { (x, y)  in
    return x < y
}
//如果只有一行 return 可以省略
popSort(&data) { (x, y) in
    x > y
}
//参数名也可以省略 $0 代表第一个参数，$1...
popSort(&data) {
    $0 < $1
}
// 参数有时候可以省略 只有逻辑了
popSort(&data, function: >)


