//: Playground - noun: a place where people can play

import UIKit

//结果体的属性 如果没有初始化 则编译器会提供一个逐一初始器（每个Init方法中 每个属性都有对应的参数）
// 如果所有的属性 都初始化了 结构体就提供了一个无参的初始化器 和 一个逐一初始化器
struct Resoulution {
    var width : Float = 0.0
    var heigth : Float = 0.0
}
var r1 = Resoulution(width: 100, heigth: 100)
var r2 = Resoulution()
r1.heigth


class VideoMode {
    var name : String?
    var frameRate : Float = 0.0
    var resolution : Resoulution = Resoulution()
}
// 类类型 默认只提供一个无参初始化器
var vmode1 = VideoMode()
var vmode2 = VideoMode()
print(unsafeAddressOf(vmode1))
print(unsafeAddressOf(vmode2))
// 引用类型 比较地址是否相同 可以使用 === 或 !==
if vmode1 === vmode2 {
    print("地址相同")
}
if vmode1 !== vmode2 {
    print("地址不同")
}

var vmode3 = vmode1
if vmode3 === vmode1{
    print("地址相同")
}

