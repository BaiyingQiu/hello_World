//: Playground - noun: a place where people can play

import UIKit

// 如果是可选值类型 默认自动初始化成nil 只有可选值类型变量 或者常量 才能赋值成nil
// Int? 是可选值类型的简化形式
var x : Int?
x = nil;
// 非简化形式
var o : Optional<Int>
o = nil;

let num = "123"
let converNum : Int? = Int(num)
//解包前需要判断是否为nil
if converNum == nil{
    print("转换失败")
} else {
    print("转换成功")
    var testValue = converNum! + 1000
}

//把一个可选值 赋值给另一个变量或者常量 则另外一个自动成为可选值
var otherNum = converNum
if otherNum == nil{
    print("不可解包")
} else {
    print("可以解包")
    var testValue = converNum! + 1000
}

//可选绑定
otherNum = 999
print(otherNum)
// 可选绑定 会自动解包 不是nil 就进入if
if var bvar = otherNum {
    print(bvar,"绑定成功");
} else {
    print("绑定失败")
}

/** Type？这种类型 叫需要强制解包的可选类型
    Type！ 自动解包可选类型，必须保证非空

*/
var var_z2 : Int!
var_z2 = 8899
print(var_z2 + 1)

// 故事板拖拽的组件在使用时 一定是非空的 所以产生的类型 是自动解包的可选类型
// 写代理时 要得到登录的状态 需要使用类型
// 使用代理时不一定有值 使用非自动解包的可选类型比较合适


