//: Playground - noun: a place where people can play

import UIKit

func fa(exterName innerName : Int) {
    // innerName 内部名 只能在函数内部使用
    print("内部名 innerName = \(innerName)")
}
//exterName外部名 只能在函数外面使用
fa(exterName: 123)


func  printInfo (name : String, age : Int) {
    print("\(name) 的年龄是\(age)")
}
//从函数的第二个参数开始 默认即是内部名又是外部名
printInfo("张三", age: 19)
//如果调用不习惯 可以去掉外部名
// _ 忽略外部名
func printInfo (name : String, _ age : Int) {
    print("\(name) 的年龄是\(age)")
}
printInfo("zhangSan", 21)

//如果不想使用默认的外部名 你还可以自己起
func printInfo (name : String, andAge age : Int) {
    print("\(name) 的年龄是\(age)")

}
printInfo("liSi", andAge: 23)