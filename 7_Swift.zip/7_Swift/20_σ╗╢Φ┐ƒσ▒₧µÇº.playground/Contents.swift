//: Playground - noun: a place where people can play

import UIKit

//延迟属性 类型OC中的懒加载
class DataImporter {
    init() {
        print("DataImporter 被创建")
    }
    var fileName = "data.txt"
}
class DataManager {
    var dataImporter = DataImporter()
    var count : Int = 0
}

var dataManager = DataManager()
dataManager.count
//只有调用.dataImporter DataImporter才会被创建（懒加载）
dataManager.dataImporter
