//: Playground - noun: a place where people can play

import UIKit

//闭包 Closer 函数类型的参数 或者变量
// OC ---- BLOCK
// Ruby -- BLOCK
// C++ --- Lamda
// JS ---- 匿名函数

// 闭包就是将一段代码封装起来 变成一个类似于变量的东西 当然 也可以作为函数的参数类型进行传递
//swift 中如果一个函数
var sayCol : (Int, Int) -> Int
func getSum(x : Int, y : Int) -> Int {
    return x + y
}
sayCol = getSum
sayCol(100, 300)
sayCol = {
    (x : Int, y : Int) -> Int in
    return x * y
}
sayCol(10, 400)

//闭包参数 （函数类型的参数）
var a = 123
var b = 456
func getResult (fun: (Int, Int) -> Int) ->Int {
    let result = fun(a, b)
    return result
}
getResult(getSum)
getResult ({ (a : Int, b : Int) -> Int in
    return a + b
})
// 函数的最后一个参数 是函数类型 则可以写在（）外书写
// 出现在最后一个位置上的函数参数，称之为 拖尾闭包
getResult { (a : Int, b : Int) -> Int in
    return a * b
}



