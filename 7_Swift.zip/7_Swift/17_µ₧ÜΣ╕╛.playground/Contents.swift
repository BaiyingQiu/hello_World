//: Playground - noun: a place where people can play

import UIKit

//常规
enum CompassPoint1 {
    case East
    case Weat
    case Sourth
    case North
}

//简化形式
enum CompassPoint2 {
    case East, Weat, Sourth, North
    //枚举中可以定义方法
    func show() {
        print(self)
    }
}
//定义一个枚举变量
var p1 = CompassPoint2.Weat
p1.show()

//枚举可以和switch使用
var p2 : CompassPoint1 = .Sourth
switch p2{
case .Sourth:
    print("南")
default:
    print("other")
}


//原始值（裸值）
enum Week : Int{
    case Sun, Mon, Tur, Wen, Thu, Fri, Sat
}

var weekDay : Int = Week.Mon.rawValue
weekDay = Week.Sat.rawValue
//使用一个整型值 构建一个枚举对象
//使用裸值 构建枚举 可能会失败
var varWeek : Week? = Week(rawValue: 1)

